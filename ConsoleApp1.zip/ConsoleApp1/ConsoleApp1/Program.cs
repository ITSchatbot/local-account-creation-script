﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        public static string Name;
        public static string Password;

        static void Main(string[] args)
        {
            Console.WriteLine("Windows Local Account Creator");
            Console.WriteLine("Enter local account IID");
            Name = Console.ReadLine();

            Console.WriteLine("Enter local account password");
            Password = Console.ReadLine();

            CreateUser(Name, Password);

        }
        public static void CreateUser(string Name, string Password)
        {
            try
            {
                DirectoryEntry AD = new DirectoryEntry("WinNT://" + Environment.MachineName + ",computer");
                DirectoryEntry NewUser = AD.Children.Add(Name, "user");
                NewUser.Invoke("SetPassword", new object[] { Password });

                NewUser.Invoke("Put", new object[] { "Description", "Test User from .NET" });
                NewUser.CommitChanges();
                DirectoryEntry grp;
                grp = AD.Children.Find("Guests", "group");
                if (grp != null) { grp.Invoke("Add", new object[] { NewUser.Path.ToString() }); }
                Console.WriteLine("Local account created successfully");
                Console.WriteLine("Press Enter key to continue");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
        }
    }
}
